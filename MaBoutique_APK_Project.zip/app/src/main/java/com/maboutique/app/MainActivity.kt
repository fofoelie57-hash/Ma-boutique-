package com.maboutique.app

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Product(var id: Long, var name: String, var category: String, var price: Double, var stock: Int)
data class Sale(var date: String, var customer: String, var phone: String, var product: String, var qty: Int, var unitPrice: Double, var total: Double, var payment: String, var paid: Double, var remaining: Double, var note: String)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("ma_boutique", MODE_PRIVATE) }
    private val products = mutableListOf<Product>()
    private val sales = mutableListOf<Sale>()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        if (products.isEmpty()) seedProducts()
        buildShell()
        showDashboard()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "🛍️  Ma Boutique"; textSize = 24f; setPadding(20,24,20,18); gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Accueil","Produits","Vente","Historique").forEach { label ->
            nav.addView(Button(this).apply {
                text = label; setOnClickListener {
                    when(label) { "Accueil"->showDashboard(); "Produits"->showProducts(); "Vente"->showSale(); else->showHistory() }
                }
            }, LinearLayout.LayoutParams(0,60,1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,30) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showDashboard() {
        content.removeAllViews()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val todaySales = sales.filter { it.date.startsWith(today) }
        val total = todaySales.sumOf { it.total }
        addTitle("Tableau de bord")
        addText("Ventes aujourd’hui : ${money(total)}")
        addText("Nombre de ventes : ${todaySales.size}")
        addText("Produits : ${products.size}")
        addText("Stock total : ${products.sumOf { it.stock }} unités")
        addText("Créances : ${money(sales.sumOf { it.remaining })}")
        val low = products.filter { it.stock <= 5 }
        addText(if (low.isEmpty()) "Stock faible : aucun" else "⚠️ Stock faible : ${low.joinToString { it.name }}")
    }

    private fun showProducts() {
        content.removeAllViews(); addTitle("Produits")
        addButton("➕ Ajouter un produit") { productDialog(null) }
        products.forEach { p ->
            val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,12,12,12) }
            addTo(box, "${p.name} — ${p.category}")
            addTo(box, "Prix : ${money(p.price)}   |   Stock : ${p.stock}")
            val row = LinearLayout(this)
            row.addView(Button(this).apply { text="Modifier"; setOnClickListener { productDialog(p) }}, LinearLayout.LayoutParams(0,60,1f))
            row.addView(Button(this).apply { text="+ Stock"; setOnClickListener { adjustStock(p, 1) }}, LinearLayout.LayoutParams(0,60,1f))
            row.addView(Button(this).apply { text="- Stock"; setOnClickListener { adjustStock(p, -1) }}, LinearLayout.LayoutParams(0,60,1f))
            box.addView(row); content.addView(box)
        }
    }

    private fun productDialog(existing: Product?) {
        val form = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,10,30,10) }
        val name = edit("Nom du produit", existing?.name ?: "")
        val cat = edit("Catégorie / format", existing?.category ?: "")
        val price = edit("Prix de vente (FCFA)", existing?.price?.toString() ?: "", true)
        val stock = edit("Quantité en stock", existing?.stock?.toString() ?: "0", true)
        listOf(name,cat,price,stock).forEach(form::addView)
        AlertDialog.Builder(this).setTitle(if(existing==null) "Ajouter" else "Modifier le produit")
            .setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer") { _,_->
                val n=name.text.toString().trim(); if(n.isEmpty()) return@setPositiveButton
                val p=price.text.toString().toDoubleOrNull() ?: 0.0
                val s=stock.text.toString().toIntOrNull() ?: 0
                if(existing==null) products.add(Product(System.currentTimeMillis(),n,cat.text.toString(),p,s))
                else { existing.name=n; existing.category=cat.text.toString(); existing.price=p; existing.stock=s }
                saveData(); showProducts()
            }.show()
    }

    private fun adjustStock(p: Product, delta: Int) {
        val input=edit("Quantité à ${if(delta>0)"ajouter" else "retirer"}","1",true)
        AlertDialog.Builder(this).setTitle("Modifier le stock").setView(input)
            .setNegativeButton("Annuler",null).setPositiveButton("OK") {_,_->
                val q=input.text.toString().toIntOrNull() ?: 0
                p.stock=maxOf(0,p.stock+delta*q); saveData(); showProducts()
            }.show()
    }

    private fun showSale() {
        content.removeAllViews(); addTitle("Nouvelle vente")
        if(products.isEmpty()){ addText("Ajoute d’abord un produit."); return }
        val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val customer=edit("Nom du client","")
        val phone=edit("Téléphone","")
        val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,products.map{"${it.name} — ${money(it.price)}"})
        val qty=edit("Quantité","1",true)
        val payment=Spinner(this); payment.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Espèces","Orange Money","Moov Money","MTN Money","Wave","Autre"))
        val paid=edit("Montant payé (FCFA)","0",true)
        val note=edit("Note","")
        val totalText=TextView(this).apply{textSize=19f;setPadding(0,12,0,12)}
        form.addView(customer);form.addView(phone);form.addView(TextView(this).apply{text="Produit";textSize=16f})
        form.addView(spinner);form.addView(qty);form.addView(payment);form.addView(paid);form.addView(totalText);form.addView(note)
        fun refresh(){ val p=products[spinner.selectedItemPosition]; val q=qty.text.toString().toIntOrNull()?:0; val t=q*p.price; val a=paid.text.toString().toDoubleOrNull()?:0.0; totalText.text="Total : ${money(t)}\nReste à payer : ${money(maxOf(0.0,t-a))}"}
        spinner.setOnItemSelectedListener(object: AdapterView.OnItemSelectedListener{override fun onNothingSelected(p0:AdapterView<*>?){};override fun onItemSelected(p0:AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){refresh()}})
        qty.setOnKeyListener{_,_,_->refresh();false}; paid.setOnKeyListener{_,_,_->refresh();false}
        content.addView(form); addButton("💾 Enregistrer la vente") {
            val p=products[spinner.selectedItemPosition]; val q=qty.text.toString().toIntOrNull()?:0
            if(q<=0 || q>p.stock){toast("Stock insuffisant.");return@addButton}
            val t=q*p.price; val a=paid.text.toString().toDoubleOrNull()?:0.0
            sales.add(Sale(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date()),
                customer.text.toString().ifBlank{"Client anonyme"},phone.text.toString(),p.name,q,p.price,t,payment.selectedItem.toString(),a,maxOf(0.0,t-a),note.text.toString()))
            p.stock-=q;saveData();toast("Vente enregistrée.");showDashboard()
        }
        refresh()
    }

    private fun showHistory() {
        content.removeAllViews(); addTitle("Historique des ventes")
        if(sales.isEmpty()){addText("Aucune vente.");return}
        sales.asReversed().forEach { s ->
            addText("${s.date}\nClient : ${s.customer}  ${if(s.phone.isNotBlank())"• "+s.phone else ""}\n${s.product} × ${s.qty} — ${money(s.total)}\nPaiement : ${s.payment} | Payé : ${money(s.paid)} | Reste : ${money(s.remaining)}${if(s.note.isNotBlank())"\nNote : "+s.note else ""}")
        }
    }

    private fun edit(hint:String,value:String="",number:Boolean=false)=EditText(this).apply{this.hint=hint;setText(value);setPadding(0,12,0,12);if(number)inputType=2}
    private fun addTitle(s:String){content.addView(TextView(this).apply{text=s;textSize=22f;setPadding(0,0,0,18)})}
    private fun addText(s:String){content.addView(TextView(this).apply{text=s;textSize=16f;setPadding(0,10,0,10)})}
    private fun addButton(s:String,action:()->Unit){content.addView(Button(this).apply{text=s;setOnClickListener{action()}})}
    private fun addTo(box:LinearLayout,s:String){box.addView(TextView(this).apply{text=s;textSize=16f})}
    private fun money(x:Double)="%.0f FCFA".format(Locale.US,x)
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    private fun seedProducts(){
        listOf("Bougie|Carton","Bougie|Paquet","Bougie|Détail","Savon|","Parfum|","Encens|","Huile sainte|","Éponge africain|","Croix de Jésus-Christ|","Tissus de soutane|","Percale|","Clochette|","Canari|Grand","Canari|Moyen","Canari|Petit").forEach{
            val a=it.split("|");products.add(Product(System.currentTimeMillis()+products.size,a[0],a.getOrElse(1){""},0.0,0))
        };saveData()
    }
    private fun saveData(){
        val po=JSONArray();products.forEach{p->po.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("category",p.category);put("price",p.price);put("stock",p.stock)})}
        val so=JSONArray();sales.forEach{s->so.put(JSONObject().apply{put("date",s.date);put("customer",s.customer);put("phone",s.phone);put("product",s.product);put("qty",s.qty);put("unitPrice",s.unitPrice);put("total",s.total);put("payment",s.payment);put("paid",s.paid);put("remaining",s.remaining);put("note",s.note)})}
        prefs.edit().putString("products",po.toString()).putString("sales",so.toString()).apply()
    }
    private fun loadData(){
        runCatching{JSONArray(prefs.getString("products","[]")).let{for(i in 0 until it.length()){val o=it.getJSONObject(i);products.add(Product(o.getLong("id"),o.getString("name"),o.optString("category"),o.optDouble("price"),o.optInt("stock")))}}}
        runCatching{JSONArray(prefs.getString("sales","[]")).let{for(i in 0 until it.length()){val o=it.getJSONObject(i);sales.add(Sale(o.getString("date"),o.getString("customer"),o.optString("phone"),o.getString("product"),o.getInt("qty"),o.getDouble("unitPrice"),o.getDouble("total"),o.getString("payment"),o.getDouble("paid"),o.getDouble("remaining"),o.optString("note")))}}}
    }
}
