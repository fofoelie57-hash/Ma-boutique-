# Ma Boutique — projet Android

Application de gestion de boutique en français.

Fonctions prévues :
- Produits : nom, catégorie/format, prix, stock
- Modification du prix et du stock à tout moment
- Ajout/retrait de stock
- Ventes avec client, téléphone, paiement, montant payé et reste
- Historique conservant le prix de chaque ancienne vente
- Tableau de bord, recherche et filtres
- Données locales sur le téléphone

## Compiler l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Gradle synchroniser les dépendances.
3. Build > Build APK(s).
4. L'APK sera généré dans `app/build/outputs/apk/debug/`.

Le projet est fourni comme base Android compilable ; l'environnement de cette conversation ne contient pas le SDK Android/Gradle nécessaire pour produire directement le binaire APK.
